<?php


// Ajax以外からのアクセスを遮断
$request = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) : '';
if($request !== 'xmlhttprequest') exit;
 
$json = file_get_contents('php://input');
$data = json_decode($json, true);
 
$text      = isset($data['text'])       ? $data['text']     : "";
$callback  = isset($_GET['callback'])   ? $_GET["callback"] : "";
$callback  = htmlspecialchars(strip_tags($callback));
 
$param = array( $file_name );
 
header('Content-type: text/javascript; charset=utf-8');
printf("{$callback}(%s)", json_encode( $param ));
