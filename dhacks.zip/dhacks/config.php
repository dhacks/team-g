<?php

define('DSN', 'mysql:dbname=dhacks;host=localhost;charset=utf8');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
