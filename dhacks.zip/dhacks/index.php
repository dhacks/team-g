<?php
require_once 'init.php';
//投稿を取得
$db = connectDb();
$records = getRecord($db);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if ($_POST['file_name'] != 'output.wav'){
    $file_name = $_POST['file_name'];
    $category = $_POST['category'];
    echo $category;
    writeRecord($db, $file_name, $category);
    // 2重投稿防止のためにリロードする処理
    header('Location: index.php');
    exit;
  }
}

?>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DHacks</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
</head>
<body>



  <div id="recorder" style="width: 340px; text-align: center;">
    <button id="record" onclick="clickRecord()">録音</button>
    <button id="stop" onclick="clickStop()">停止</button>
    <button id="play" onclick="clickPlay()">再生</button>
    <div id="wami"></div>
    <div id="meter" style="width: 340px; height: 200px;"></div> <!--justgageはサイズ指定必須-->
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>
  <script src="recorder.js"></script>
  <script src="raphael-2.1.4.min.js"></script>
  <script src="justgage.js"></script>
  <script src="wami.js"></script>
  <form action="index.php" method="POST">
    <select name="category">
      <option value="couple">カップル</option>
      <option value="etiquette">エチケット</option>
      <option value="gossip">噂</option>
      <option value="r18">R18</option>
      <option value="others">その他</option>
    </select>
    <input type="hidden" name="file_name" value="">
    <button type="submit" class="btn btn-primary" id="post-button">投稿する</button>
  </form>



  <div class="panel panel-default">
    <!-- Default panel contents -->
    <div class="panel-heading">
      <h3 class="panel-title">みんなの投稿</h3>
    </div>
    <!-- List group -->
    <ul class="list-group">
      <?php if (!$records): ?>
      <li class="list-group-item">
        <div class="container-fluid">
          <p class="text-center">
            <strong>投稿がありません。</strong>
          </p>
        </div>
      </li>
    <?php else: ?>
    // 投稿がある場合の処理
    <?php foreach ($records as $key => $value):
    try {
      $post_by = getRecordData($db, $value['id']);
    } catch (Exception $e) {
      print $e->getMessage();
    }
    ?>
    <?php if (isset($post_by)): ?>
    <li class="list-group-item">
      <div class="container-fluid">
        <!-- 投稿ファイルネーム -->
        <p class="small text-muted reply-to">@<?php print escape(
          $post_by['name']
          ) ?></p>
          <!-- カテゴリ -->
          <p>カテゴリ：<?php print escape($value['category']) ?></p>
          <!-- 投稿日時 -->
          <p class="small"><?php print $value['created_at'] ?></p>
          <!-- 返信・削除ボタン -->
          <p class="text-right">
            <button type="button" class="btn btn-primary reply-btn" data-toggle="modal"
            data-target="#replyModal">
            <span class="glyphicon glyphicon-send" aria-hidden="true"></span>　いいね
          </button>
          <button type="button" class="btn btn-danger reply-btn" name="delete_post"
          onclick="">
          <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>　通報
        </button>
      </p>
    </div>
  </li>
<?php endif; ?>
<?php endforeach; ?>
<?php endif; ?>
</ul>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

</script>
</body>
</html>